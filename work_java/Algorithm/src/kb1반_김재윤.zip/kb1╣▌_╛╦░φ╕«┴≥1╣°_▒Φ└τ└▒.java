import java.util.*;
import java.io.*;

public class kb1반_알고리즘1번_김재윤 {
	static ArrayList<Integer>[] friends;
	static boolean isfriends[];
	static int N, M, cnt;

	public static void main(String[] args) throws IOException {
		BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
		StringTokenizer st = new StringTokenizer(br.readLine());
		N = Integer.parseInt(st.nextToken());

		st = new StringTokenizer(br.readLine());
		M = Integer.parseInt(st.nextToken());

		friends = new ArrayList[N + 1];
		isfriends = new boolean[N + 1];
		for (int i = 1; i <= N; i++)
			friends[i] = new ArrayList<>();

		for (int i = 0; i < M; i++) {
			st = new StringTokenizer(br.readLine());
			int n1 = Integer.parseInt(st.nextToken());
			int n2 = Integer.parseInt(st.nextToken());
			friends[n1].add(n2);
			friends[n2].add(n1);
		}
		cnt = 0;
		isfriends[1]=true;
		dfs(1);
		System.out.println(cnt);
	}// etc

	static void dfs(int num) {
		for (int i = 0; i < friends[num].size(); i++)
			if (!isfriends[friends[num].get(i)]) {
				cnt++;
				isfriends[friends[num].get(i)] = true;
				dfs(friends[num].get(i));
			}

	}
}// etc
